#include "Filter.h"

Filter::Filter()
{

}

Filter::~Filter() {}
