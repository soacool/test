The Code folder contains the code samples used in this book.

Software_Hardware_list file contains the list of required software and hardware for this book.

Happy coding! :)